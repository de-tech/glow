Intel(R) XDK, May 2015
 
This plugins directory is created automatically when you select a plugin
in the PROJECTS tab under Cordova Hybrid Mobile App Settings > Plugins.
 
Do NOT modify the contents of any files in this plugins directory or
add/delete its files.  Any changes made here will be ignored by the Intel XDK,
such as when you package your app with the BUILD tab, or use other tabs that
run, debug, profile or test your app on your device with Intel App Preview. 
 
We recommend that you do not put this directory under source control.
 
Do not be concerned if some of your selected plugins are missing from this
directory. That is normal.
